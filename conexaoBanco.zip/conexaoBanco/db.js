// const { Pool } = require("pg");

async function connect() {  
    const { Pool } = require("pg");

    if(global.connection)
        return global.connection.connect();

    const pool = new Pool({
      user: process.env.USER_NAME,
      host: process.env.HOST_NAME,
      database: process.env.DB_NAME,
      password: process.env.DB_PASSWORD,
      dialect: process.env.DB_DIALECT,
      port: process.env.PORT_NUMBER
    });
    
    const client = await pool.connect();
    console.log("O Pool de conexão foi criado com sucesso!")
    client.release();

    global.connection = pool;
    
    return pool.connect();
  }

  connect();
  // Função para listar um cliente
async function selectCustomer(id) {
  // Estabelece a conexão com o banco de dados
  const client = await connect();
  // Executa a query SQL usando declaração preparada para evitar SQL Injection
  const res = await client.query("SELECT * FROM client WHERE cpf=$1", [id]);
  // Retorna as linhas (dados do cliente)
  return res.rows;
  }

  // Função para inserir clientes no banco de dados. Essa função recebe informações vindos da rota POST.
async function insertCustomer(customer) {
  // Estabelecer conexão com o banco de dados (a função "connect" deve ser definida em outro lugar)
  const client = await connect();
  // Prepara a query SQL de inserção com parâmetros para evitar SQL Injection
  const sql = "INSERT INTO client (cpf, nome, email, idade, profissao) VALUES ($1, $2, $3, $4, $5)";
  // Cria um array com os valores que serão injetados na query, na ordem correta
  const values = [customer.cpf, customer.nome, customer.email, customer.idade, customer.profissao];
  // Executa a query no banco de dados para inserir o cliente
  await client.query(sql, values);
  }

// Função para excluir cliente
async function deleteCustomer(id) {
  // Estabelecer conexão
  const client = await connect();
  // parâmetros que devem ser injetados
  const sql = "DELETE FROM client WHERE cpf=$1";
  const values = [id];
  
  await client.query(sql, values)
  }

  // Função para listar clientes
async function selectCustomers() {
  // Estabelecer conexão com o banco de dados
  const client = await connect();
  // Enviar comando SQL para o banco de dados
  const res = await client.query("SELECT * FROM client");
  // Retorna as linhas (registros) da tabela
  return res.rows;
  }
  // Exporta a função para que ela possa ser usada em outras partes do backend
  module.exports = {
  insertCustomer,
  selectCustomers,
  selectCustomer,
  deleteCustomer
  }